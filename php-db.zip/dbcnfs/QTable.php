<?php
/**
 * Created by PhpStorm.
 * User: krismatt
 * Date: 20/07/2016
 * Time: 01:36
 */

require_once("DBBuilder.php");

class QTable {

    public static function GetByd($ColId="id",$ColValue="",$total=1,$TableName){
        if($total<=1){
            return (new Table($TableName))->Get()->Where($ColId,"=",$ColValue)->First();
        }else{
            return (new Table($TableName))->Get()->Where($ColId,"=",$ColValue)->All();
        }
    }

    public static function GetSimple($ColValue="",$TableName){
        return (new Table($TableName))->Get()->Where("id","=",$ColValue);
    }

    public static function Get($Table){

    }
} 