<?php
require_once("DBBuilder.php");
require_once("QueryResult.php");
require_once("Table.php");
require_once("Tables.php");

class Query{
    private $Query=null;
    private $Reflector=null;
    public  $PDOObject=null;
    private $QueryResult=null;
    private $QueryType=null;

    private function Decode(){
        /*
         * Template Decode(Connection::GetString())
         * user=root;pass=locFalmaster;url=localhost;port=80
        */
        if(Connection::GetString()!=null && Connection::GetString().''!=''){
            $Cnfs=Connection::GetString();
            $CnfsArray=explode(";",$Cnfs);
            $CnfsDictionnary=null;
            foreach ($CnfsArray as $cnfs) {
                if(explode("=",$cnfs)[0]!='') {
                    $CnfsDictionnary[strtolower('' . explode("=", $cnfs)[0] . '')] = explode("=", $cnfs)[1];
                }
            }
            if($CnfsDictionnary!=null){
                $User="";$Pass="";$DBName="";$Url="";
                foreach($CnfsDictionnary as $Key=>$Value){
                    $key=strtolower(''.$Key.'');
                    if($key=='user' || $key=='uid'|| $key=='user-id' ||$key=='owner'){
                        $User=str_replace(' ','',$Value.'');
                    }
                    if($key=='pass'|| $key=='pwd'||$key=='passwd'||$key=='secret'){
                        $Pass=$Value;
                    }
                    if($key=='srv'||$key=='url'||$key=='server'||$key=='s-url'){
                        $Url=str_replace(' ','%20',$Value.'');
                    }
                    if($key=='db'||$key=='dbname'||$key=='use'){
                        $DBName=str_replace(' ','',$Value.'');
                    }
                }
                try{
                     $this->PDOObject=new PDO("mysql:host=".$Url.";dbname=".$DBName,$User,$Pass);
                    //$this->PDOObject=new PDO("mysql:host=".$Url.";dbname=".$DBName,
                        //                $User,$Pass);
                    //$this->PDOObject=new PDO("mysql:host=clustermysql01.hosteur.com;dbname=esgis17_web","esgis17_web","50609515a776f");
                }
                catch(Exception $ex){
                    //$this->SetLastError($ex->getMessage());
                }
            }
        }
        else{
        }
    }

    public function __construct($query=''){
        Connection::Make();
        $this->Query=$query;
        $this->Decode();
    }
    private function SetQuery($Query){
        $this->Reflector=new Query($this->Query." $Query");
    }

    public static function exec($query=null){
        return (new Query($query))->Apply();
    }

    public function GetQuery(){
        return $this->Query;
    }

    public function Distinct($Column){
        return new Query($this->Query." DISTINCT($Column) ");
    }

    /**
     * @return null
     */
    private function GetQueryType(){
        return $this->QueryType;
    }

    /**
     * @param $Tables
     * @return null|Query
     */
    public function From($Tables){
        $this->Reflector=new Query($this->Query." FROM $Tables");
        return $this->Reflector;
    }

    public function Where($Column,$SQLOp='=',$Value){
        if($Value instanceof Query){
            $this->Reflector=new Query($this->Query." WHERE $Column $SQLOp (".$Value->GetQuery().")");
        }elseif(is_array($Value)){
            $SQLOp=str_replace(" ","",$SQLOp);
            $retqwery="";
            if(strtolower($SQLOp)=="between" || strtolower($SQLOp)=="not between"){
                $retqwery=" ".strtoupper($SQLOp)." ".$Value[0]." AND ".$Value[1];
            }
            elseif(strtolower($SQLOp)=="in" || strtolower($SQLOp)=="not in"){
                $qwery="";
                foreach($Value as $tab){
                    if(is_array($tab)){
                        $qwery.="'".$tab[0]."',";
                    }
                    else{
                        $qwery.="'".$tab."',";
                    }
                }
                $qwery.="]";
                $qwery="(".str_replace(",]",")",$qwery);
                $retqwery=" ".strtoupper($SQLOp)." ".$qwery;
            }
            $this->Reflector=new Query($this->Query." WHERE $Column ".$retqwery."");
        }else{
            if(strtolower($SQLOp)=='=='){
                $SQLOp='=';
                $Value="".str_replace("'","''",$Value)."";
            }
            else{
                $Value="'".str_replace("'","''",$Value)."'";
            }
            $this->Reflector=new Query($this->Query." WHERE $Column $SQLOp $Value");
        }
        return $this->Reflector;
    }

    public function __And($Column,$SQLOp='=',$Value){
        if($Value instanceof Query){
            $this->Reflector=new Query($this->Query." AND $Column $SQLOp (".$Value->GetQuery().")");
        }elseif(is_array($Value)){
            $SQLOp=str_replace(" ","",$SQLOp);
            $retqwery="";
            if(strtolower($SQLOp)=="between"){
                $retqwery=" BETWEEN ".$Value[0]." AND ".$Value[1];
            }
            elseif(strtolower($SQLOp)=="in"){
                $qwery="";
                foreach($Value as $tab){
                    if(is_array($tab)){
                        $qwery.="'".$tab[0]."',";
                    }
                    else{
                        $qwery.="'".$tab."',";
                    }
                }
                $qwery.="]";
                $qwery="(".str_replace(",]",")",$qwery);
                $retqwery=" IN ".$qwery;
            }
            $this->Reflector=new Query($this->Query." AND $Column ".$retqwery."");
        }else{
            if(strtolower($SQLOp)=='=='){
                $SQLOp='=';
                $Value="".str_replace("'","''",$Value)."";
            }
            else{
                $Value="'".str_replace("'","''",$Value)."'";
            }
            $this->Reflector=new Query($this->Query." AND $Column $SQLOp $Value");
        }
        return $this->Reflector;
    }

    public function __Or($Column,$SQLOp='=',$Value){
        if($Value instanceof Query){
            $this->Reflector=new Query($this->Query." OR $Column $SQLOp (".$Value->GetQuery().")");
        }elseif(is_array($Value)){
            $SQLOp=str_replace(" ","",$SQLOp);
            $retqwery="";
            if(strtolower($SQLOp)=="between"){
                $retqwery=" BETWEEN ".$Value[0]." OR ".$Value[1];
            }
            elseif(strtolower($SQLOp)=="in"){
                $qwery="";
                foreach($Value as $tab){
                    if(is_array($tab)){
                        $qwery.="'".$tab[0]."',";
                    }
                    else{
                        $qwery.="'".$tab."',";
                    }
                }
                $qwery.="]";
                $qwery="(".str_replace(",]",")",$qwery);
                $retqwery=" IN ".$qwery;
            }
            $this->Reflector=new Query($this->Query." OR $Column ".$retqwery."");
        }else{
            if(strtolower($SQLOp)=='=='){
                $Value="".str_replace("'","''",$Value)."";
            }
            else{
                $Value="'".str_replace("'","''",$Value)."'";
            }
            $SQLOp='=';
            $this->Reflector=new Query($this->Query." OR $Column $SQLOp $Value");
        }
        return $this->Reflector;
    }

    public function OrderBy($Column,$Order="DESC"){
        if(strpos($this->Query,'ORDER BY')==false){
            $this->Reflector=new Query($this->Query." ORDER BY $Column $Order");
        }else{
            $this->Reflector=new Query($this->Query.",$Column $Order");
        }
        return $this->Reflector;
    }

    public function Having($Column,$SQLOp,$Value="ASC"){
        if($Value instanceof Query){
            $this->Reflector=new Query($this->Query." HAVING $Column $SQLOp (".$Value->GetQuery().")");
        }elseif(is_array($Value)){
            $SQLOp=str_replace(" ","",$SQLOp);
            $retqwery="";
            if(strtolower($SQLOp)=="between"){
                $retqwery=" BETWEEN ".$Value[0]." HAVING ".$Value[1];
            }
            elseif(strtolower($SQLOp)=="in"){
                $qwery="";
                foreach($Value as $tab){
                    if(is_array($tab)){
                        $qwery.="'".$tab[0]."',";
                    }
                    else{
                        $qwery.="'".$tab."',";
                    }
                }
                $qwery.="]";
                $qwery="(".str_replace(",]",")",$qwery);
                $retqwery=" IN ".$qwery;
            }
            $this->Reflector=new Query($this->Query." HAVING $Column ".$retqwery."");
        }else{
            $Value="'".str_replace("'","''",$Value)."'";
            $this->Reflector=new Query($this->Query." HAVING $Column $SQLOp $Value");
        }
        return $this->Reflector;
    }

    public function GroupBy($Column){
        $this->Reflector=new Query($this->Query." GROUP BY $Column");
        return $this->Reflector;
    }

    public function Set($Dict){
        if($Dict!=null && count($Dict)>0){
            $inside="";
            foreach($Dict as $Key=>$Value){
                $inside.="$Key='".str_replace("'","''",utf8_decode($Value))."', ";
            }
            $inside.="]";
            $inside=str_replace(", ]"," ",$inside);
            if(strpos($this->Query,'SET')==false) {
                $this->Reflector = new Query($this->Query . " SET " . " $inside");
            }
            else{
                $this->Reflector = new Query($this->Query . "," . " $inside");
            }
        }
        return $this->Reflector;
    }

    public function All($showIndexes=false,$AsObj=false){
        if($this->PDOObject!=null){
            $res=$this->PDOObject->query($this->GetQuery());
        }
        else{
            return null;
        }
        $All=null;
        if($res){
            if($AsObj==true){
                $showIndexes=false;
                while($data=$res->fetch(PDO::FETCH_OBJ)){
                    $array=[];
                    foreach($data as $k=>$v){
                        $array[strtolower($k)]=($v);
                    }
                    $All[]=$array;
                }
            }else{
                while($data=$res->fetch()){
                    $array=[];
                    foreach($data as $k=>$v){
                        $array[strtolower($k)]=($v);
                    }
                    $All[]=$array;
                }
            }
            if($showIndexes==true) {
                if($All!=null){
                    $rowCopy=[];
                    $k=0;
                    foreach($All as $row=>$rowval){
                        foreach($rowval as $col=>$value) {
                            $rowCopy[$k][$col] = utf8_encode($value);
                        }
                        $k++;
                    }
                    return $rowCopy;
                }
                return null;
            }
            else{
                if($All!=null){
                    $rowCopy=[];
                    $k=0;
                    foreach($All as $row=>$rowval){
                        foreach($rowval as $col=>$value) {
                            if (!is_int($col)) {
                                $rowCopy[$k][$col] = utf8_encode($value);
                            }
                        }
                        $k++;
                    }
                    return $rowCopy;
                }
                return null;
            }
        }
        return null;
    }

    public function Range($min=-1,$max=-1){
        $Data=null;
        if($min>0 && ($max>=$min)){
            try{
                for($i=$min;$i<=$max;$i++){
                    $Data[]=$this->All()[$i];
                }
            }
            catch(Exception $ex){
            }
            return $Data;
        }
        else{
            return null;
        }
    }

    public function Get($index=-1){
        try{
            return $this->All()[$index-1];
        }
        catch(Exception $ex){
            return null;
        }
    }

    public function First($showIndexes=false){
        try{
            return $this->All($showIndexes)[0];
        }
        catch(Exception $ex){
            return null;
        }
    }

    public function Last(){
        try{
            return $this->All()[count($this->All())-1];
        }
        catch(Exception $ex){
            return null;
        }
    }

    public function Count(){
        try{
            return count($this->All());
        }
        catch(Exception $ex){
            return 0;
        }
    }

    public function Apply(){
        try{
            return $this->PDOObject->exec($this->GetQuery());
        }
        catch(Exception $ex){
            echo $ex->getMessage();
            return false;
        }
    }
}

?>
