<?php
require_once("Connection.php");
require_once("Query.php");
  function NotNull($var){
    return ($var!=null || ($var.''!=''));
}

class DBType{
  const ORACLE=1;
  const MySQL =2;
  const PostgreSQL=4;
}

class DBBuilder {
    private $CnxString=null;
    private $User=null;
    private $ServerUrl=null;
    private $Name=null;
    private $Pass=null;
    public $PDOObject=null;
    private $Error=null;

    public static function Table($Name){
        return new Table($Name);
    }

    public static function Tables($Name){
        return new Tables($Name);
    }

    public function GetLastError(){
        return $this->Error;
    }

    private function SetLastError($Error){
        $this->Error=$Error;
    }

    public function __construct($DBName,$Type=DBType::MySQL){
        if(!isset($DBName)){
            if(Connection::GetString()!=null && Connection::GetString()!=''){
                $this->CnxString=Connection::GetString();
                Connection::Make();
                $this->Decode();
            }
        }
        elseif(isset($DBName) && $DBName!=null){
            Connection::SetString("user=root;pwd=localmaster;url=localhost;db=".$DBName);
            $this->CnxString=Connection::GetString();
            Connection::Make();
            $this->Decode();
        }
    }

    public static function exec($sql){
        return (new Query($sql));
    }

    private function Decode(){
        /*
         * Template Decode(Connection::GetString())
         * user=root;pass=localmaster;url=localhost;port=80
        */
        if(Connection::GetString()!=null && Connection::GetString().''!=''){
            $Cnfs=Connection::GetString();
            $CnfsArray=explode(";",$Cnfs);
            $CnfsDictionnary=null;
            foreach ($CnfsArray as $cnfs) {
                if(explode("=",$cnfs)[0]!='') {
                    $CnfsDictionnary[strtolower('' . explode("=", $cnfs)[0] . '')] = explode("=", $cnfs)[1];
                }
            }
            if($CnfsDictionnary!=null){
                foreach($CnfsDictionnary as $Key=>$Value){
                    $key=strtolower(''.$Key.'');
                    if($key=='user' || $key=='uid'|| $key=='user-id' ||$key=='owner'){
                        $this->User=str_replace(' ','',$Value.'');
                    }
                    if($key=='pass'|| $key=='pwd'||$key=='passwd'||$key=='secret'){
                        $this->Pass=$Value;
                    }
                    if($key=='srv'||$key=='url'||$key=='server'||$key=='s-url'){
                        $this->ServerUrl=str_replace(' ','',$Value.'');
                    }
                    if($key=='db'||$key=='dbname'||$key=='use'){
                         $this->Name=str_replace(' ','',$Value.'');
                    }
                }
                try{
                    $this->PDOObject=new PDO("mysql:host=".$this->ServerUrl.";dbname=".$this->Name,
                                    $this->User,$this->Pass);
                }
                catch(Exception $ex){
                  $this->SetLastError($ex->getMessage());
                }
            }
        }
        else{
        }
    }

    public function LoadTable($TableName){
       return new Table($TableName);
    }
}
 ?>
