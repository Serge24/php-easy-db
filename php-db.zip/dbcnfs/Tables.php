<?php
require_once("Query.php");
class Tables{
    private $Error;
    private $TableName;
    private $PDOObject;
    private $QResult;
    private $ListResult;


    public function GetLastError(){
        return $this->Error;
    }

    private function SetLastError($Err){
        $this->Error=$Err;
    }
    public function __construct($Name){
        Connection::Make();
        $Tables=null;
        if(is_array($Name) && count($Name)>0){
            foreach($Name as $CurrTable){
                $Tables.="info_$CurrTable,";
            }
            $Tables.="]";
            $Tables=str_replace(",]"," ",$Tables);
            $Tables=str_replace(":"," ",$Tables);
            $this->TableName=$Tables;
        }
        else{
            $this->TableName="info_".str_replace(":"," ",$Name);
        }
        $this->Decode();
    }

    private function Decode(){
        /*
         * Template Decode(Connection::GetString())
         * user=root;pass=localmaster;url=localhost;port=80
        */
        if(Connection::GetString()!=null && Connection::GetString().''!=''){
            $Cnfs=Connection::GetString();
            $CnfsArray=explode(";",$Cnfs);
            $CnfsDictionnary=null;
            foreach ($CnfsArray as $cnfs) {
                if(explode("=",$cnfs)[0]!='') {
                    $CnfsDictionnary[strtolower('' . explode("=", $cnfs)[0] . '')] = explode("=", $cnfs)[1];
                }
            }
            if($CnfsDictionnary!=null){
                $User="";$Pass="";$DBName="";$Url="";
                foreach($CnfsDictionnary as $Key=>$Value){
                    $key=strtolower(''.$Key.'');
                    if($key=='user' || $key=='uid'|| $key=='user-id' ||$key=='owner'){
                        $User=str_replace(' ','',$Value.'');
                    }
                    if($key=='pass'|| $key=='pwd'||$key=='passwd'||$key=='secret'){
                        $Pass=$Value;
                    }
                    if($key=='srv'||$key=='url'||$key=='server'||$key=='s-url'){
                        $Url=str_replace(' ','%20',$Value.'');
                    }
                    if($key=='db'||$key=='dbname'||$key=='use'){
                        $DBName=str_replace(' ','',$Value.'');
                    }
                }
                try{
                    $this->PDOObject=new PDO("mysql:host=".$Url.";dbname=".$DBName,
                        $User,$Pass);
                }
                catch(Exception $ex){
                    $this->SetLastError($ex->getMessage());
                }
            }
        }
        else{
        }
    }

    public function Update(){
        return new Query("UPDATE ".$this->TableName);
    }

    public function Delete(){
        return new Query("DELETE FROM ".$this->TableName);
    }

    public function Where($Column,$SQLOp,$Value){
        return $this->Get()->Where($Column,$SQLOp,$Value);
    }

    public function First($showIndexes=false){
        return $this->Get()->First($showIndexes);
    }

    public function Last($showIndexes=false){
        return $this->Get()->Last($showIndexes);
    }

    public function Get($Columns=null){
        if(is_array($Columns) && $Columns!=null && count($Columns)>0 && isset($Columns)){
            $ColumnsList="";
            foreach($Columns as $Cols){
                $ColumnsList.="$Cols,";
            }
            $ColumnsList.="]";
            $ColumnsList=str_replace(",]"," ",$ColumnsList);
            $ColumnsList=str_replace(":"," AS ",$ColumnsList);
            return new Query("SELECT $ColumnsList FROM ".$this->TableName);
        }
        elseif(!is_array($Columns) && isset($Columns)){
            $Columns=str_replace(":"," AS ",$Columns);
            return new Query("SELECT $Columns FROM ".$this->TableName);
        }
        else{//if(!isset($Columns) || $Columns==null){
            return new Query("SELECT * FROM ".$this->TableName);
        }
    }

    public function Distinct($Columns=null){
        if(is_array($Columns) && $Columns!=null && count($Columns)>0 && isset($Columns)){
            $ColumnsList="";
            foreach($Columns as $Cols){
                $ColumnsList.="$Cols,";
            }
            $ColumnsList.="]";
            $ColumnsList=str_replace(",]"," ",$ColumnsList);
            $ColumnsList=str_replace(":"," AS ",$ColumnsList);
            return new Query("SELECT DISTINCT $ColumnsList FROM ".$this->TableName);
        }
        elseif(!is_array($Columns) && isset($Columns)){
            $Columns=str_replace(":"," AS ",$Columns);
            return new Query("SELECT DISTINCT $Columns FROM ".$this->TableName);
        }
        else{//if(!isset($Columns) || $Columns==null){
            return new Query("SELECT * FROM ".$this->TableName);
        }
    }

    public function Desc(){
        $res=$this->PDOObject->query("DESCRIBE ".$this->TableName);
        $ret=null;
        while($qres=$res->fetch()){
            $ret[]=$qres;
        }
        return $ret;
    }

    public function Drop(){
        return (new Query("DROP TABLE ".$this->TableName))->Apply();
    }

    public function Count($Column){
        if($Column==null || $Column==''){
            return (new Query("SELECT COUNT(*) FROM ".$this->TableName))->First()[0];
        }
        else{
            return (new Query("SELECT COUNT($Column) FROM ".str_replace(":"," ",$this->TableName)));
        }
    }

    public function Add($Dict){
        $q=new Query("INSERT INTO ".$this->TableName." (");
        if($Dict!=null && count($Dict)>0){
            foreach($Dict as $Col=>$Value){
                $q=new Query($q->GetQuery()." $Col,");
            }
            $q=new Query($q->GetQuery()."]");
            $Qwery=str_replace(",]",")",$q->GetQuery());
            $q=new Query($Qwery." VALUES(");
            foreach($Dict as $Col=>$Value){
                $q=new Query($q->GetQuery()."'".str_replace("'","''",$Value)."',");
            }
            $q=new Query($q->GetQuery()."]");
            $Qwery=str_replace(",]",")",$q->GetQuery());
            return (new Query($Qwery))->Apply();
        }
        return -1;
    }
    /*
       public function ToArrayObject($Columns=null){
            $Qwery="";
            if(is_array($Columns) && isset($Columns) && count($Columns)>0){
                $ListColumns=null;
                foreach($Columns as $Column){
                    $ListColumns.="$Column,";
                }
                $ListColumns.="]";
                $ListColumns=str_replace(",]","",$ListColumns);
                $ListColumns=str_replace(":"," AS ",$ListColumns);
                $Qwery="SELECT $ListColumns FROM ".$this->TableName;
            }
            elseif(!is_array($Columns) && isset($Columns)){
                $Qwery="SELECT $Columns FROM ".$this->TableName;
            }
            elseif(!isset($Columns) || $Columns==null){
                $Qwery="SELECT * FROM ".$this->TableName;
            }
            $qres=$this->PDOObject->query($Qwery);
            while($data=$qres->fetch()){
                $ListClmns=null;
                foreach($data as $Key=>$Val){
                    if(!is_int($Key)){
                      $this->QResult[strtolower("$Key")]="$Val";
                    }
                }
                $this->ListResult[]=$this->QResult;
                //echo $this->nom." ".$this->login."<br/>";
            }
            //print_r($this->ListResult);
            $Obj=null;
            foreach($this->ListResult as $Lst){
                $getter=new Table($this->TableName);
                foreach($Lst as $Col=>$Val){
                    $this->__set(strtolower("$Col"),$Val);
                    $getter->__set(strtolower("$Col"),$Val);
                }
                $Obj[]=$getter;
                //$this->QResult=$Lst;
                echo $this->nom."<br/>";
            }
            return $Obj;
       }
    */
    function __set($key,$value){
        $this->QResult[strtolower("$key")]=$value;
    }

    function __get($key){
        return $this->QResult[strtolower("$key")];
    }
}
?>
