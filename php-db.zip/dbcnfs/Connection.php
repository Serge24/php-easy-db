<?php

class Connection{
    private static $CnxString="";

    public static function Make(){
        Connection::$CnxString="srv=localhost;uid=esgis17_web;pass=50609515a776f;db=esgis17_web";
        Connection::$CnxString="srv=localhost;uid=root;pass=localmaster;db=esgis17_web";
    }

    public static function SetString($Cnx){
        Connection::$CnxString=$Cnx;
    }

    public static function GetString(){
        return Connection::$CnxString;
    }
}
?>
