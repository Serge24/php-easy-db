<?php
require_once("DBBuilder.php");
class QueryResult{
private $attr;

   function __set($name,$val){
        $this->attr[$name]=$val;
   }
   function __get($name){
        return $this->attr[$name];
   }

   public function __construct($ListAttributes=null){
        foreach($ListAttributes as $Key=>$Value){
            $this->__set(strtolower($Key),str_replace("''","'",$Value));
        }
   }

}
?>
